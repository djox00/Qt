#ifndef CONSTS
#define CONSTS
const int DataSize=100;
const int BufferSize=5;
#endif // CONSTS

