#ifndef COMMON
#define COMMON
#include <QSemaphore>
#include "consts.h"

extern char buffer[BufferSize];
extern QSemaphore slobodniBajti;
extern QSemaphore iskoristeniBajti;
#endif // COMMON

